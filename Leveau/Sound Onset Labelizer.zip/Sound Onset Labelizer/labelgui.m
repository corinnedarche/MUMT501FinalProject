function varargout = labelgui(varargin)
% LABELGUI Application M-file for labelgui.fig
%    FIG = LABELGUI launch labelgui GUI.
%    LABELGUI('callback_name', ...) invoke the named callback.
% Sound onset labelization GUI
% ------------------------------------------------------------------

% Copyright Pierre Leveau, contributors : Laurent Daudet, Gael Richard
% 
% e-mail: leveau@lam.jussieu.fr
% 
% This software is a computer program whose purpose is to manually put 
% notes onsets on .wav musical files (mono).
% 
% This software is governed by the CeCILL  license under French law and
% abiding by the rules of distribution of free software.  You can  use, 
% modify and/ or redistribute the software under the terms of the CeCILL
% license as circulated by CEA, CNRS and INRIA at the following URL
% "http://www.cecill.info". 
% 
% As a counterpart to the access to the source code and  rights to copy,
% modify and redistribute granted by the license, users are provided only
% with a limited warranty  and the software's author,  the holder of the
% economic rights,  and the successive licensors  have only  limited
% liability. 
% 
% In this respect, the user's attention is drawn to the risks associated
% with loading,  using,  modifying and/or developing or reproducing the
% software by the user in light of its specific status of free software,
% that may mean  that it is complicated to manipulate,  and  that  also
% therefore means  that it is reserved for developers  and  experienced
% professionals having in-depth computer knowledge. Users are therefore
% encouraged to load and test the software's suitability as regards their
% requirements in conditions enabling the security of their systems and/or 
% data to be ensured and,  more generally, to use and operate it in the 
% same conditions as regards security. 
% 
% The fact that you are presently reading this means that you have had
% knowledge of the CeCILL license and that you accept its terms.

% Last modification: 02/02/2005
% Last Modified by GUIDE v2.0 26-Aug-2004 18:13:23

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sys variable
% if your system is based on unix, "sys" must be equal to 'sys_unix'
% otherwise type 'sys_no_unix'. 
% Warning: Mac OS X is considered as 'sys_no_unix'.
global sys;
sys = 'sys_no_unix';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'reuse');

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
    % handles data init:
    handles.ZoomWindow = [];
    handles.Fs = 0;
    handles.SigIn = [];
    handles.MSP = 0;
	handles.FN_LabelFilePath = [];
    handles.F_Label = [];
    handles.FN_SoundFile = [];
    guidata(fig, handles);
    

	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		if (nargout)
			[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
		else
			feval(varargin{:}); % FEVAL switchyard
		end
	catch
		disp(lasterr);
	end

end


% --------------------------------------------------------------------
function varargout = B_ZoomPrec_Callback(h, eventdata, handles, varargin)
% Previous Zoom
 
SWP = size(handles.ZoomWindow);
if SWP(1) <= 1
else
    handles.ZoomWindow = handles.ZoomWindow(1:end-1,:);
    set(handles.axes1, 'Xlim',handles.ZoomWindow(end,:));
    set(handles.axes2, 'Xlim',handles.ZoomWindow(end,:));
end

guidata(gcbo, handles);

% --------------------------------------------------------------------
function varargout = B_Play_Callback(h, eventdata, handles, varargin)
% Plays the sound un the current window

ech1 = max([1 (floor(handles.Fs * handles.ZoomWindow(end,1)) + 1)]);
ech2 = min([floor(handles.Fs * handles.ZoomWindow(end,2)) length(handles.SigIn)]);

myplaysc(handles.SigIn(ech1:ech2),handles.Fs);

guidata(gcbo, handles);

% --------------------------------------------------------------------
function varargout = B_Zoom_Callback(h, eventdata, handles, varargin)
% Zoom between 2 selected points

[t,y,button] = ginput(2);

if t(1)>=t(2)
    return
else
    axes(handles.axes1);
    xlim([t(1) t(2)]);
    axes(handles.axes2);
    xlim([t(1) t(2)]); 
end

handles.ZoomWindow = [handles.ZoomWindow;get(handles.axes1, 'XLim')];

guidata(gcbo, handles);
% --------------------------------------------------------------------
function varargout = B_Load_Callback(h, eventdata, handles, varargin)
% Loads the sound file, displays the signal and its spectrogram, the labels if they exist

[handles.FN_SoundFile, FN_SoundFilePath] = uigetfile('*.wav', 'Choose the sound file to label');
if handles.FN_SoundFile == 0
    return
end
[handles.SigIn, handles.Fs, Nbits] = wavread(fullfile(FN_SoundFilePath, handles.FN_SoundFile));
handles.SigIn = mean(handles.SigIn,2);

%
% Sig2plot = 1;
if isempty(handles.FN_LabelFilePath)
    [handles.F_Label, handles.FN_LabelFilePath] = B_ChangeLabFolder_Callback(h, eventdata, handles, varargin);
%     Sig2plot = 0;
end
handles.F_Label = [handles.FN_LabelFilePath handles.FN_SoundFile(1:end-4) '.mat'];    


% Renew the figures.
%if Sig2plot, 
DisplaySigplot(h, eventdata, handles);
%, end;

DisplaySpectrogram(h, eventdata, handles);


% If a label file has been created previously, the labels are loaded, else a labels file is created.
if exist(handles.F_Label)
    load(handles.F_Label);
    handles.labels_time = labels_time;
    
    handles.labels = PlotLabels(handles.labels_time, handles.axes1);  % conversion handles.labels_time en handles.labels (handle et time)
    
    ResetLabelBrowser(h, eventdata, handles, varargin);
    
      
else
    InitLabels(h, eventdata, handles, varargin);
    
end

Tbound = get(handles.axes1, 'Xlim');
handles.ZoomWindow = [0 Tbound(2)];  %T(end)];

set(handles.E_DialogField, 'String', ['File ' handles.FN_SoundFile ' loaded, labels in ' handles.FN_LabelFilePath]);
guidata(gcbo, handles);
% --------------------------------------------------------------------
function varargout = E_DialogField_Callback(h, eventdata, handles, varargin)




% --------------------------------------------------------------------
function varargout = B_SaveLabel_Callback(h, eventdata, handles, varargin)
% Adds a Label

axes(handles.axes1);
[xl,yl,bl] = ginput(1);
hl = line([xl xl],[1 -1], 'Color', 'r');

% Inserts a new label in the handles.labels tab
handles.labels = [handles.labels;struct('handle',hl,'time',xl)];


% Sorts labels in tab
handles.labels_time = sort([handles.labels(:).time]');

for n = 1:length(handles.labels)
    k = find([handles.labels(:).time]' == handles.labels_time(n));
    handles.labels_temp(n,1) = handles.labels(k);
end
handles.labels = handles.labels_temp;

% Updates the current label
CurLab = find(handles.labels_time == xl);
set(handles.E_LabelNumber,'String',num2str(CurLab));

HighLightLabel(CurLab, handles);

% Updates the label
UpdateLabelSlider(h, eventdata, handles, varargin);

handles.labels_time = [handles.labels(:).time]';
labels_time = handles.labels_time;
save(handles.F_Label,'labels_time');

set(handles.E_DialogField, 'String', ['Label ' num2str(CurLab) ' added']);
guidata(gcbo, handles);


% --------------------------------------------------------------------
function varargout = E_LabelNumber_Callback(h, eventdata, handles, varargin)
% Highlights the current label

CurLab = str2num(get(handles.E_LabelNumber,'String'));


HighLightLabel(CurLab, handles);
guidata(gcbo, handles);
% --------------------------------------------------------------------
function varargout = S_LabelNumber_Callback(h, eventdata, handles, varargin)
% Updates the current label number

Val = round(get(handles.S_LabelNumber, 'Value') * (length(handles.labels)-1) + 1);

set(handles.E_LabelNumber,'String',num2str(Val));



E_LabelNumber_Callback(h, eventdata, handles);


guidata(gcbo, handles);

% --------------------------------------------------------------------
function varargout = B_DelLabel_Callback(h, eventdata, handles, varargin)
% Deletes a label

CurLab = str2num(get(handles.E_LabelNumber,'String'));
set(handles.labels(CurLab).handle, 'Visible', 'off');


% label deletion
if length(handles.labels) == 1 |  length(handles.labels) == 0
    handles.labels = [];
elseif CurLab + 1>length(handles.labels)
    handles.labels = handles.labels(1:end-1);
    CurLab = CurLab - 1;
elseif CurLab - 1 <= 0
    handles.labels = handles.labels(2:end) ;
else
    handles.labels = [handles.labels(1:CurLab-1);handles.labels(CurLab+1:end)];
end

set(handles.E_LabelNumber, 'string', num2str(CurLab));

HighLightLabel(CurLab, handles);

% Updates the slider
UpdateLabelSlider(h, eventdata, handles, varargin);


handles.labels_time = [handles.labels(:).time]';
labels_time = handles.labels_time;
save(handles.F_Label,'labels_time');

set(handles.E_DialogField, 'String', ['Label deleted']);
guidata(gcbo, handles);

% --------------------------------------------------------------------
function HighLightLabel(CurLab, handles);
% Highlights the label

if length(handles.labels) == 0
    return
end


axes(handles.axes1);
for n = 1:length(handles.labels)
    set(handles.labels(n).handle, 'Color', 'g');
end
set(handles.labels(CurLab).handle, 'Color', 'r');

guidata(gcbo, handles);

% --------------------------------------------------------------------
function varargout = S_Contrast_Callback(h, eventdata, handles, varargin)
% Sets the spectrogram contrast 

Contrast = 96 * get(handles.S_Contrast, 'Value');
axes(handles.axes2);
caxis([handles.MSP-10-Contrast handles.MSP]);
guidata(gcbo, handles);

% --------------------------------------------------------------------
function varargout = S_Amp_Callback(h, eventdata, handles, varargin)
% Sets the amplitude factor

FacAmp = 10^(2 * get(handles.S_Amp, 'Value'));
set(handles.axes1, 'Ylim', [-1 1]/FacAmp);

guidata(gcbo, handles);




% --------------------------------------------------------------------
function varargout = B_PlayUNLab_Callback(h, eventdata, handles, varargin)
% Plays until next label


T = (1:length(handles.SigIn))/handles.Fs;

CurLab = str2num(get(handles.E_LabelNumber,'String'));

ech1 = floor(handles.Fs * handles.labels(CurLab).time);



if CurLab == length(handles.labels) % si c'est le dernier label, on en joue au max 1/2 seconde
    ech2 = min([(ech1 + floor(handles.Fs/2)) length(handles.SigIn)]);
    myplaysc(handles.SigIn(ech1:ech2), handles.Fs);
else
    ech2 = floor(handles.Fs * handles.labels(CurLab+1).time); 
    myplaysc(handles.SigIn(ech1:ech2), handles.Fs);
end
guidata(gcbo, handles);







% --------------------------------------------------------------------
function varargout = T_MoveMode_Callback(h, eventdata, handles, varargin)
% allows to move the label

CurLab = str2num(get(handles.E_LabelNumber,'String'));

axes(handles.axes1);

while get(handles.T_MoveMode, 'Value') == get(handles.T_MoveMode, 'Max')
    
    ap = (get(handles.CB_Autoplay, 'Value') == get(handles.CB_Autoplay, 'Max'));
    [x,y,b] = ginput(1);
    
    % if the click is out the axes
    if abs(y) > max(abs(get(handles.axes1, 'Ylim'))') | x > max(get(handles.axes1, 'Xlim')') | x < min(get(handles.axes1, 'Xlim')')
        set(handles.T_MoveMode, 'Value', 0.0);
        return
       
    else
        % if left click, we move the label onto the click place
        if b == 1
            set(handles.labels(CurLab).handle, 'XData', [x x]);
            handles.labels(CurLab).time = x;
            
            
            labels_time = [handles.labels(:).time]';
            save(handles.F_Label,'labels_time');
            
        % if right click, we move the label on the left or on the right (by  a step of 5ms) depending on the click side  
        else
            if x > handles.labels(CurLab).time
                handles.labels(CurLab).time = handles.labels(CurLab).time + 0.005;
                set(handles.labels(CurLab).handle, 'XData', [handles.labels(CurLab).time handles.labels(CurLab).time]);
                
                labels_time = [handles.labels(:).time]';
                save(handles.F_Label,'labels_time');    
            else
                handles.labels(CurLab).time = handles.labels(CurLab).time - 0.005;
                set(handles.labels(CurLab).handle, 'XData', [handles.labels(CurLab).time handles.labels(CurLab).time]);
                
                labels_time = [handles.labels(:).time]';
                save(handles.F_Label,'labels_time');    

            end
            
        end
        if ap  % if 'autoplay', we play from the previous label.
            B_PlayFPLab_Callback(h, eventdata, handles, varargin);
            
        end
        
    end
    
end

guidata(gcbo, handles);               
                
    


% --------------------------------------------------------------------
function varargout = CB_Autoplay_Callback(h, eventdata, handles, varargin)




% --------------------------------------------------------------------
function varargout = B_PlayFPLab_Callback(h, eventdata, handles, varargin)
% Plays the signal betwenn the current label and the previous one

T = (1:length(handles.SigIn))/handles.Fs;

CurLab = str2num(get(handles.E_LabelNumber,'String'));

ech2 = floor(handles.Fs * handles.labels(CurLab).time);


if CurLab == 1 % si c'est le premier label, on joue au max une demi-seconde avt le deb
    ech1 = max([(ech2 - floor(handles.Fs/2)) 1]);
    myplaysc(handles.SigIn(ech1:ech2), handles.Fs);
else
    ech1 = floor(handles.Fs * handles.labels(CurLab-1).time); 
    myplaysc(handles.SigIn(ech1:ech2), handles.Fs);
end
guidata(gcbo, handles);


% --------------------------------------------------------------------
function varargout = B_ChangeLabFolder_Callback(h, eventdata, handles, varargin)
% Changes the labelFolder

[FN_LabelFile, handles.FN_LabelFilePath] = uigetfile('*.*', 'Choose a file in the new labels folder');
if FN_LabelFile == 0
    return
end
set(handles.E_DialogField, 'String', ['Labels in ' handles.FN_LabelFilePath]);

DisplaySigplot(h, eventdata, handles);

if ~isempty(handles.FN_SoundFile) 
    handles.F_Label = [handles.FN_LabelFilePath handles.FN_SoundFile(1:end-4) '.mat'];
    if exist(handles.F_Label)
        load(handles.F_Label);
        handles.labels_time = labels_time;
        handles.labels = PlotLabels(handles.labels_time, handles.axes1);
        
        ResetLabelBrowser(h, eventdata, handles, varargin);
    else
        InitLabels(h, eventdata, handles, varargin);
    end
end

varargout{1} = handles.F_Label;
varargout{2} = handles.FN_LabelFilePath;

guidata(gcbo, handles);

% ---------------------------------------------------------------------------
function DisplaySpectrogram(h, eventdata, handles, varargin)
L = length(handles.SigIn);
T = (1:L)/handles.Fs;
axes(handles.axes2);
NFFT = 1024;
HopSize = 128;
[SP,F,T] = specgram([zeros(floor(NFFT/2),1);handles.SigIn],NFFT,handles.Fs,hanning(NFFT),NFFT - HopSize);
ZerosSP = find(SP == 0);
SP(ZerosSP) = eps;
SPdB = 20*log10(abs(SP));
imagesc(T,F,SPdB);
axis xy;

colormap(1-gray);

axis([0 T(end) 0 floor(handles.Fs/2)]);
handles.MSP = max(max(SPdB));

Contrast = 96 * get(handles.S_Contrast, 'Value');

caxis([handles.MSP-10-Contrast handles.MSP]);
ylabel('Fr�quence [Hz]');


% ---------------------------------------------------------------------------
function DisplaySigplot(h, eventdata, handles, varargin)
L = length(handles.SigIn);
T = (1:L)/handles.Fs;
axes(handles.axes1);
plot(T,handles.SigIn);
ylabel('Amplitude');
axis([0 T(end) -1 1]);

% ---------------------------------------------------------------------------
function UpdateLabelSlider(h, eventdata, handles, varargin)

if length(handles.labels) ~= 0
    set(handles.S_LabelNumber, 'SliderStep', (1/(length(handles.labels)))*[1 1] ); % Updates the slider
end

% ---------------------------------------------------------------------------
function ResetLabelBrowser(h, eventdata, handles, varargin)
set(handles.E_LabelNumber,'String','');
if length(handles.labels)>=1
    UpdateLabelSlider(h, eventdata, handles, varargin);
    set(handles.E_LabelNumber,'String',num2str(1));
    HighLightLabel(1, handles);  
end
    
% ---------------------------------------------------------------------------
function InitLabels(h, eventdata, handles, varargin)    
handles.labels = [];
handles.labels_time = [];
labels_time = handles.labels_time;
save(handles.F_Label,'labels_time');

guidata(gcbo, handles);

% -----------------------------------------------------------------------------
function m = myplaysc(varargin)
%MYPLAYSC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%

global sys

switch(lower(sys))
    
case ''
    disp('!!! Please initialyze sys variable in labelgui.m (line 48)');
    
case 'sys_unix'
    if length(varargin)==1
        sf=44100;
    else
        sf=varargin{2};
    end;
    sig=varargin{1};
    sig = (.999/max(abs(sig))) * sig;
    
    wavwrite(sig,sf,'/tmp/tmp.wav');
    unix('play /tmp/tmp.wav');
    unix('rm /tmp/tmp.wav');
    
case 'sys_no_unix'
    soundsc(varargin{1}, varargin{2});
    
otherwise
    error('''sys'' variable in labelgui.m must be ''sys_unix'' or ''sys_no_unix''')
end
    
% ---------------------------------------------------------------------------
function L = PlotLabels(L_time,haxes, varargin)
% PLOTLABELS
%   This function plots the labels on the axes.

if ~isempty(varargin)
    Lcolor = varargin{1};
else
    Lcolor = 'g';
end

axes(haxes);
L = [];
for n = 1:length(L_time)
        L(n).handle = line([L_time(n) L_time(n)] ,[-2 2], 'Color', Lcolor);
        rectangle('Position', [L_time(n) - 0.05 -2 0.1 4],...
           'FaceColor', [0.95 0.95 0.95],...
           'EdgeColor', [0.95 0.95 0.95],...
           'EraseMode', 'xor');
        L(n).time = L_time(n);
end
L = L(:);